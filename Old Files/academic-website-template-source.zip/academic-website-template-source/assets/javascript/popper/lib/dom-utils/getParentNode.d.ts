export default function getParentNode(element: Node | ShadowRoot): Node;
